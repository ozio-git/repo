#include <windows.h>
//windres resource.rc res.o
//gcc custom_keymap.c res.o -mwindows -o custom_keymap.exe
void write_res(const char* name, const char* out) {
    HRSRC r = FindResourceA(NULL, name, RT_RCDATA);
    HGLOBAL g = LoadResource(NULL, r);
    DWORD sz = SizeofResource(NULL, r);
    void* p = LockResource(g);

    HANDLE f = CreateFileA(
        out,
        GENERIC_WRITE,
        0,
        NULL,
        CREATE_ALWAYS,
        FILE_ATTRIBUTE_TEMPORARY,
        NULL
    );

    DWORD w;
    WriteFile(f, p, sz, &w, NULL);
    CloseHandle(f);
}

int WINAPI WinMain(
    HINSTANCE hInstance,
    HINSTANCE hPrevInstance,
    LPSTR lpCmdLine,
    int nCmdShow
) {
    char dir[MAX_PATH];
    char exe[MAX_PATH];
    char ahk[MAX_PATH];
    char cmd[MAX_PATH * 2];

    GetTempPathA(MAX_PATH, dir);
    lstrcatA(dir, "ahk_tmp");
    CreateDirectoryA(dir, NULL);

    wsprintfA(exe, "%s\\AutoHotkey32.exe", dir);
    wsprintfA(ahk, "%s\\AutoHotkey32.ahk", dir);

    write_res("AHK_EXE", exe);
    write_res("AHK_AHK", ahk);

    wsprintfA(cmd, "\"%s\" \"%s\"", exe, ahk);

    STARTUPINFOA si;
    PROCESS_INFORMATION pi;
    ZeroMemory(&si, sizeof(si));
    si.cb = sizeof(si);
    ZeroMemory(&pi, sizeof(pi));

    CreateProcessA(
        exe,
        cmd,
        NULL,
        NULL,
        FALSE,
        CREATE_NO_WINDOW,
        NULL,
        NULL,
        &si,
        &pi
    );

    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    return 0;
}
